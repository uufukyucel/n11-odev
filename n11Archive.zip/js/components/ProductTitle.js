Vue.component('product-title', {
    props: ['title'],
    template: `<h4 class="text-2xl text-black">{{ title }}</h4>`,
})